/* 
 * File:   ChipConfig.h
 */

#ifndef CHIPCONFIG_H
#define	CHIPCONFIG_H

#define FCY 40000000

void InitOscillator();

#endif	/* CHIPCONFIG_H */

